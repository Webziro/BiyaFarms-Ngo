<footer class="footer-14">
          <div id="footers14-block">
              <div class="container">
                  <div class="footers20-content">
                      <div class="d-grid grid-col-4 grids-content">
                          <div class="column">
                              <h4>Visit us at </h4>
                                <p> Biyafarms Initiative for the less privileged
                                    2, Katako Junction, Jos, Nigeria
                                </p>
                          </div>
                          <div class="column">
                              <h4>Call Us</h4>
                              <p>Talk to us any day of the week</p>
                              <p><a href="tel:+234 704 980 3097">+234 704 980 3097</a></p>
                          </div>
                          <div class="column">
                              <h4>Mail Us</h4>
                              <p><a href="mailto:info@example.com">info@biflp.ng</a></p>
                          </div>
                          <div class="column">
                              <h4>Follow Us On</h4>
                              <ul>
                                  <li><a href="https://web.facebook.com/biflp"><span class="fa fa-facebook"
                                              aria-hidden="true"></span></a>
                                  </li>
                                  
                                  <li><a href="instagram.com/biflp_"><span class="fa fa-twitter"
                                              aria-hidden="true"></span></a>
                                  </li>
                                  
                              </ul>
                          </div>
                      </div>
                  </div>
                  <div class="footers14-bottom d-flex">
   
                  <div class="copyright">
                          <p>© <?php echo date("Y"); ?> <a href="+2347067085121"
                                  target="_blank">Developed by Webziro</a></p>
                      </div>



                  