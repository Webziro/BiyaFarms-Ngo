<?php
$hostname = 'localhost'; 
$database = 'biflp'; 
$db_user = 'root'; 
$db_pass = ''; 
$conn = mysqli_connect("$hostname", "$db_user" , "$db_pass", "$database");
